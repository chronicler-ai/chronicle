---
date: 2024-05-07
tags:
  - resources
  - snippets
---

# Snippet Garden

Mature code snippets live here once they graduate from [[Visualization Ideas]].
- Implementation notes link back to [[Project Seeds]].
- Usage stories and retro notes update [[Learning Nodes]].

```dataviewjs
const rows = dv.pages("20 Dataview Queries").map(page => [page.file.link, page.date]);
dv.table(["Snippet", "Date"], rows);
```
