---
date: 2024-05-03
tags:
  - resources
  - learning
---

# Learning Nodes

I maintain research breadcrumbs here.
- Each lesson references [[Reference Library]] for source notes.
- Practical exercises cross-link to [[Query Cookbook]].
- Future reading flows through [[Community Radar]].

| Topic | Status | Next |
| --- | --- | --- |
| Inline fields | Draft | [[Visualization Ideas]] |
| Calendar blocks | Review | [[Daily Flow]] |
