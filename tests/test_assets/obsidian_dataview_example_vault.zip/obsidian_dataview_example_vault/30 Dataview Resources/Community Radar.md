---
date: 2024-05-04
tags:
  - resources
  - community
---

# Community Radar

Highlights from the community feed into my relationship strategy.
- Owner context references [[Stakeholder Map]].
- Follow-up notes land in [[Relationship Ledger]].
- Shared discoveries inspire [[Snippet Garden]].

| Contact | Signal | Follow-up |
| --- | --- | --- |
| Forum lead | query helper | [[Task Dashboard]] |
| Stream host | plugin ideas | [[Learning Nodes]] |
