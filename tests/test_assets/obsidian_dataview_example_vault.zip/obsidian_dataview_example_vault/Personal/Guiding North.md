---
date: 2024-05-02
tags:
  - personal
  - vision
---

# Guiding North

Vision statements here keep strategy anchored.
- Translating into routines happens in [[Daily Flow]].
- Scope boundaries align with [[Vault Overview]].
- Emotional context references [[Energy Log]].

| Pillar | Focus |
| --- | --- |
| Craft | Build thoughtful dataview stories |
| Community | Support [[Community Radar]] |
