---
date: 2024-05-06
tags:
  - personal
  - relationships
---

# Relationship Ledger

This tracks commitments and next small touch points.
- It inherits radar signals from [[Community Radar]].
- Shared planning reflects stories logged in [[Daily Flow]].
- Accountability loops back into [[Stakeholder Map]].

| Name | Status | Next Action |
| --- | --- | --- |
| Project buddy | replied | send summary to [[Project Seeds]] |
| Mentor | pending | share snippet from [[Snippet Garden]] |
