---
date: 2024-05-05
tags:
  - personal
  - energy
---

# Energy Log

This rolling log annotates peaks and dips during the week.
- Trending tags inform adjustments in [[Daily Flow]].
- Alerts trigger widgets in [[Task Dashboard]].
- Reflective summaries sync with [[Guiding North]].

| Date | State | Linked Note |
| --- | --- | --- |
| 2024-05-04 | focused | [[Query Cookbook]] |
| 2024-05-05 | low | [[Visualization Ideas]] |
