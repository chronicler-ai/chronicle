---
date: 2024-05-08
tags:
  - projects
  - backlog
---

# Project Seeds

Seed ideas are captured here before they grow into real tracks.
- Visual ideas go to [[Snippet Garden]] for reuse.
- Active experiments sync dashboards inside [[Task Dashboard]].
- Library research is mirrored in [[Reference Library]].

| Idea | Next Link |
| --- | --- |
| Dataview automation | [[Query Cookbook]] |
| Relationship CRM | [[Relationship Ledger]] |
