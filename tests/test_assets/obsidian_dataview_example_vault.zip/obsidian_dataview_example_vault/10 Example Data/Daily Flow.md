---
date: 2024-05-05
tags:
  - routines
  - example
---

# Daily Flow

Morning reviews start in [[Vault Overview]] and end with action capture in [[Task Dashboard]].
Energy checkpoints reference [[Energy Log]] so retros stay grounded.

| Block | Focus | Linked Note |
| --- | --- | --- |
| Morning | Planning | [[Guiding North]] |
| Midday | Delivery | [[Project Seeds]] |
| Evening | Reflection | [[Relationship Ledger]] |
