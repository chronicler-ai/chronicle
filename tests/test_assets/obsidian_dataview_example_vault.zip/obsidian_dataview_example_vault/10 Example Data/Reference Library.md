---
date: 2024-05-09
tags:
  - library
  - research
---

# Reference Library

This curated stack tracks references that inform my ops.
- Learning references aggregate into [[Learning Nodes]].
- Visualization examples remix inside [[Visualization Ideas]].
- Personal insights tag back to [[Guiding North]].

| Title | Reason | Link |
| --- | --- | --- |
| Dataview Bible | Query patterns | [[Query Cookbook]] |
| Ritual Reset | Lifestyle prompts | [[Daily Flow]] |
