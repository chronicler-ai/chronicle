---
date: 2024-05-04
tags:
  - dataview
  - queries
---

# Query Cookbook

Reusable query blocks live here for fast prototyping.
- Dashboards embed via [[Task Dashboard]].
- Visual experiments feed into [[Visualization Ideas]].
- It references planning context from [[Vault Overview]].

```dataview
TABLE file.mtime as "Last Updated"
FROM "10 Example Data"
WHERE contains(file.tags, "projects")
```
