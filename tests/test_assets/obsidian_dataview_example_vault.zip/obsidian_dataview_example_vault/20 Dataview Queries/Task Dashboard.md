---
date: 2024-05-05
tags:
  - dataview
  - tasks
---

# Task Dashboard

Tasks roll up from [[Daily Flow]] checkpoints and backlog items in [[Project Seeds]].
- Widgets reuse queries from [[Query Cookbook]].
- Highlights are piped to [[Energy Log]] for context.

```dataview
TASK FROM "10 Example Data"
WHERE !completed
GROUP BY file.folder
```
