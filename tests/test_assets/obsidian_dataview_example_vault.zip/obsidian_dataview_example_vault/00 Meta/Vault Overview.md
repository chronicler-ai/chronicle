---
date: 2024-05-05
tags:
  - meta
  - system
---

# Vault Overview

This note defines why the vault exists and how other maps fit together.
- The operating rhythm lives in [[Daily Flow]].
- Execution recipes are catalogued in [[Query Cookbook]].
- Personal intent stays aligned through [[Guiding North]].

I capture snapshots of changes as of 2024-05-05 so archival queries stay deterministic.
