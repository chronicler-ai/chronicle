---
date: 2024-05-07
tags:
  - meta
  - loop
---

# Circular Loop

This playful note demonstrates a circular reference.
- I point to myself via [[Circular Loop]] to prove the ring closes.
- The loop feeds planning energy back into [[Guiding North]].
- When habits update in [[Daily Flow]], they echo here for auditing.

Circular thinking is intentional here so debugging graphs is easy.
