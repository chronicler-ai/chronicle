---
date: 2024-05-06
tags:
  - meta
  - relationships
---

# Stakeholder Map

This canvas tracks contributors and expectations for the workspace.
- Community touchpoints aggregate in [[Community Radar]].
- Direct commitments sync with [[Relationship Ledger]].
- Delivery cadences mirror the focus windows from [[Daily Flow]].

Every voice is logged with tags so dataview can pivot by role or intent.
